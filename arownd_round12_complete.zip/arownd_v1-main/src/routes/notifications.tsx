import { createFileRoute, Link, useNavigate, useRouter } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, ArrowRight, Bell, Lock, Package, Tag, CalendarCheck, Info, Trash2, CheckCircle2, MoreHorizontal } from "lucide-react";
import { useAuth } from "@/lib/auth";
import { useRealtimeSubscription } from "@/hooks/use-realtime";
import { fetchMyNotifications, markNotificationsRead, markNotificationRead, deleteNotification } from "@/lib/sooqy";
import { formatDateTime } from "@/lib/market";
import { EmptyState } from "@/components/sooqy/empty-state";
import { ErrorState } from "@/components/sooqy/error-state";
import { cn } from "@/lib/utils";
import { SeoHead } from "@/components/seo/SeoHead";
import { useState } from "react";
import { toast } from "sonner";
import { goBackOrTo } from "@/lib/nav";

export const Route = createFileRoute("/notifications")({
  head: () => ({}),
  component: NotificationsPage,
});

const TYPE_ICON = {
  order: Package,
  offer: Tag,
  reservation: CalendarCheck,
  system: Info,
  info: Info,
} as const;

type NotificationData = {
  order_id?: string;
  reservation_id?: string;
  offer_id?: string;
  store_id?: string;
  product_id?: string;
  status?: string;
  [key: string]: unknown;
};

function navigateForNotification(navigate: ReturnType<typeof useNavigate>, n: { type: string; data: NotificationData }) {
  const d = n.data as NotificationData;
  switch (n.type) {
    case "order":
      if (d.order_id) navigate({ to: "/orders/$orderId", params: { orderId: d.order_id } });
      else navigate({ to: "/orders" });
      break;
    case "reservation":
      // رقم الحجز ليس رقم طلب: نفتح المنتج أو المتجر إن توفّرا، وإلا قائمة الطلبات
      if (d.product_id) navigate({ to: "/products/$productId", params: { productId: d.product_id } });
      else if (d.store_id) navigate({ to: "/stores/$storeId", params: { storeId: d.store_id } });
      else navigate({ to: "/orders" });
      break;
    case "offer": {
      const productId = d.product_id ?? d.offer_id;
      if (productId) navigate({ to: "/products/$productId", params: { productId } });
      else if (d.store_id) navigate({ to: "/stores/$storeId", params: { storeId: d.store_id } });
      else navigate({ to: "/" });
      break;
    }
    case "system":
    case "info":
    default:
      // لا يوجد توجيه افتراضي للإشعارات العامة
      break;
  }
}

function NotificationsPage() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const router = useRouter();
  const navigate = useNavigate();
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const q = useQuery({
    queryKey: ["notifications"],
    queryFn: fetchMyNotifications,
    enabled: !!user,
  });

  // تحديثات حية: إشعارات جديدة (Supabase Realtime)
  useRealtimeSubscription({
    table: "notifications",
    filter: user?.id ? `user_id=eq.${user.id}` : undefined,
    queryKeys: [["notifications"]],
    enabled: !!user,
  });

  const markAll = async () => {
    try {
      await markNotificationsRead();
      await qc.invalidateQueries({ queryKey: ["notifications"] });
    } catch {
      toast.error("تعذّر تحديث الإشعارات");
    }
  };

  const handleMarkRead = async (id: string) => {
    try {
      await markNotificationRead(id);
      await qc.invalidateQueries({ queryKey: ["notifications"] });
    } catch {
      toast.error("تعذّر تحديث الإشعار");
    }
  };

  const handleDelete = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setDeletingId(id);
    try {
      await deleteNotification(id);
      qc.invalidateQueries({ queryKey: ["notifications"] });
      toast.success("تم حذف الإشعار");
    } catch {
      toast.error("فشل الحذف");
    } finally {
      setDeletingId(null);
    }
  };

  const handleClick = (n: { type: string; data: unknown; read: boolean; id: string }) => {
    if (!n.read) handleMarkRead(n.id);
    navigateForNotification(navigate, { type: n.type, data: n.data as NotificationData });
  };

  return (
    <>
      <SeoHead
        title="الإشعارات"
        description="تابع تحديثات طلباتك وحجوزاتك وعروض المتاجر."
        keywords="الإشعارات, Arownd"
        ogType="website"
      />
      <div className="px-4 pt-4">
        <header className="flex items-center justify-between py-1">
          <div className="flex items-center gap-2">
            <button onClick={() => goBackOrTo(router, "/")} aria-label="رجوع" className="icon-btn">
              <ArrowRight className="size-5" />
            </button>
            <h1 className="text-h2 text-foreground">الإشعارات</h1>
          </div>
          {q.data && q.data.some((n) => !n.read) && (
            <button
              type="button"
              onClick={() => void markAll()}
              className="min-h-11 px-2 text-sm font-bold text-accent-ink"
            >
              قراءة الكل
            </button>
          )}
        </header>

        {!user && (
          <EmptyState
            Icon={Lock}
            title="سجّل الدخول لعرض إشعاراتك"
            hint="تظهر إشعارات طلباتك وحجوزاتك بعد تسجيل الدخول."
            action={
              <Link to="/auth" className="btn-small">
                تسجيل الدخول
              </Link>
            }
          />
        )}

        {user && q.isLoading && (
          <div className="space-y-3 py-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-16 animate-pulse rounded-2xl bg-muted" />
            ))}
          </div>
        )}

        {user && q.isError && (
          <ErrorState scope="notifications" error={q.error} onRetry={() => void q.refetch()} />
        )}

        {user && q.data && q.data.length === 0 && (
          <div className="flex flex-col items-center justify-center py-24 text-center">
            <span className="flex size-20 items-center justify-center rounded-3xl bg-primary-soft">
              <Bell className="size-9 text-accent-ink" strokeWidth={1.6} />
            </span>
            <h2 className="mt-5 text-h3 text-foreground">لا توجد إشعارات بعد</h2>
            <p className="mt-2 max-w-xs text-body text-muted-foreground">
              عندما تصلك تحديثات عن طلباتك أو عروض جديدة من المتاجر، ستظهر هنا.
            </p>
            <Link to="/" className="btn-small mt-6">
              تصفح المنتجات
            </Link>
          </div>
        )}

        {user && q.data && q.data.length > 0 && (
          <div className="space-y-2 py-4">
            {q.data.map((n) => {
              const Icon = TYPE_ICON[n.type as keyof typeof TYPE_ICON] ?? Info;
              const isExpanded = expandedId === n.id;
              const open = () => handleClick(n);

              return (
                <div
                  key={n.id}
                  className={cn(
                    "card-premium !shadow-none p-3",
                    !n.read && "!border-accent-ink/30 bg-primary-soft/40",
                  )}
                >
                  <div className="flex items-start gap-3">
                    <span className="mt-0.5 flex size-9 shrink-0 items-center justify-center rounded-full bg-primary-soft text-accent-ink-soft-foreground">
                      <Icon className="size-4" aria-hidden="true" />
                    </span>
                    <div
                      role="button"
                      tabIndex={0}
                      onClick={open}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" || e.key === " ") {
                          e.preventDefault();
                          open();
                        }
                      }}
                      className="min-w-0 flex-1 cursor-pointer text-start outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    >
                      <p className="flex items-center gap-1.5 text-sm font-bold text-foreground">
                        {n.title}
                        {!n.read && (
                          <span
                            className="size-2 shrink-0 rounded-full bg-primary"
                            aria-label="غير مقروء"
                          />
                        )}
                      </p>
                      {n.body && <p className="mt-0.5 text-xs text-muted-foreground">{n.body}</p>}
                      <p className="mt-1 text-[10px] text-muted-foreground">
                        {formatDateTime(n.created_at)}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setExpandedId(isExpanded ? null : n.id)}
                      aria-expanded={isExpanded}
                      aria-label={isExpanded ? "إخفاء الخيارات" : "خيارات الإشعار"}
                      className="icon-btn shrink-0"
                    >
                      <MoreHorizontal className="size-4" aria-hidden="true" />
                    </button>
                  </div>
                  {isExpanded && (
                    <div className="mt-2 grid grid-cols-2 gap-2 border-t border-border pt-2">
                      {!n.read ? (
                        <button
                          type="button"
                          onClick={() => void handleMarkRead(n.id)}
                          className="flex min-h-11 items-center justify-center gap-1.5 rounded-xl bg-primary-soft text-xs font-bold text-accent-ink"
                        >
                          <CheckCircle2 className="size-4" aria-hidden="true" /> تعيين كمقروء
                        </button>
                      ) : (
                        <span />
                      )}
                      <button
                        type="button"
                        onClick={(e) => void handleDelete(n.id, e)}
                        disabled={deletingId === n.id}
                        className="flex min-h-11 items-center justify-center gap-1.5 rounded-xl bg-danger-soft text-xs font-bold text-danger disabled:opacity-50"
                      >
                        {deletingId === n.id ? (
                          <span className="size-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
                        ) : (
                          <Trash2 className="size-4" aria-hidden="true" />
                        )}
                        حذف
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </>
  );
}