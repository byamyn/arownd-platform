import { useCallback, useEffect, useState, type ReactNode } from "react";
import useEmblaCarousel from "embla-carousel-react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

export function Carousel({
  children,
  className,
  slideClassName,
  showArrows = false,
  onIndexChange,
}: {
  children: ReactNode[];
  className?: string;
  slideClassName?: string;
  showArrows?: boolean;
  onIndexChange?: (index: number) => void;
}) {
  const [emblaRef, emblaApi] = useEmblaCarousel({ align: "start", containScroll: "trimSnaps" });
  const [canPrev, setCanPrev] = useState(false);
  const [canNext, setCanNext] = useState(false);

  const update = useCallback(() => {
    if (!emblaApi) return;
    setCanPrev(emblaApi.canScrollPrev());
    setCanNext(emblaApi.canScrollNext());
    onIndexChange?.(emblaApi.selectedScrollSnap());
  }, [emblaApi, onIndexChange]);

  useEffect(() => {
    if (!emblaApi) return;
    update();
    emblaApi.on("select", update);
    emblaApi.on("reInit", update);
    return () => {
      emblaApi.off("select", update);
      emblaApi.off("reInit", update);
    };
  }, [emblaApi, update]);

  return (
    <div className={cn("group relative", className)}>
      <div ref={emblaRef} className="overflow-hidden">
        <div className="flex touch-pan-y">
          {children.map((child, i) => (
            <div
              key={i}
              className={cn(
                "min-w-0 shrink-0 grow-0 basis-[85%] pl-3 first:pl-0 sm:basis-[60%]",
                slideClassName,
              )}
            >
              {child}
            </div>
          ))}
        </div>
      </div>
      {showArrows && (
        <>
          <button
            aria-label="السابق"
            onClick={() => emblaApi?.scrollPrev()}
            disabled={!canPrev}
            className="absolute top-1/2 right-0 z-10 flex size-8 -translate-y-1/2 items-center justify-center rounded-full bg-card/90 text-foreground shadow-lift backdrop-blur transition disabled:opacity-0"
          >
            <ChevronRight className="size-4 rtl:rotate-180" />
          </button>
          <button
            aria-label="التالي"
            onClick={() => emblaApi?.scrollNext()}
            disabled={!canNext}
            className="absolute top-1/2 left-0 z-10 flex size-8 -translate-y-1/2 items-center justify-center rounded-full bg-card/90 text-foreground shadow-lift backdrop-blur transition disabled:opacity-0"
          >
            <ChevronLeft className="size-4 rtl:rotate-180" />
          </button>
        </>
      )}
    </div>
  );
}
