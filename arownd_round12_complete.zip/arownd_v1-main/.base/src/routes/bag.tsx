import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { AlertTriangle, ArrowLeft, ShoppingBag, Store, Trash2 } from "lucide-react";
import { useBag } from "@/lib/bag";
import { translate, useTranslation } from "@/lib/i18n";
import { evaluateBag } from "@/lib/bag-check";
import { formatDA } from "@/lib/geo";
import { getOffersByIds, primaryImage } from "@/lib/sooqy";
import { getShippingFee } from "@/lib/shipping";
import { QtyStepper } from "@/components/sooqy/qty-stepper";
import { EmptyState } from "@/components/sooqy/empty-state";
import { AppShell } from "@/components/sooqy/app-shell";
import { SectionHeader } from "@/components/sooqy/section-header";
import { StickyActionBar } from "@/components/sooqy/sticky-action-bar";
import { ConfirmDialog } from "@/components/sooqy/confirm-dialog";

export const Route = createFileRoute("/bag")({
  head: () => ({
    meta: [
      { title: translate("bag_title") },
      { name: "description", content: translate("bag_description") },
    ],
  }),
  component: BagPage,
});

function BagPage() {
  const bag = useBag();
  const { t, lang } = useTranslation();
  const [confirmClear, setConfirmClear] = useState(false);
  const ids = bag.items.map((i) => i.offerId);
  const offers = useQuery({ queryKey: ["bag-offers", ids], queryFn: () => getOffersByIds(ids) });

  // مصدر واحد للحقيقة: نفس التقييم المستخدَم في صفحة الدفع.
  const evaluation = evaluateBag(bag.items, offers.data, lang);
  const rows = evaluation.rows;

  // التجميع حسب المتجر
  const groups = new Map<string, typeof rows>();
  for (const r of rows) {
    const key = r.offer?.store.name ?? t("bag_other_store");
    groups.set(key, [...(groups.get(key) ?? []), r]);
  }

  const subtotal = evaluation.subtotal;
  let wilayaId: number | null = null;
  try {
    const w = localStorage.getItem("sooqy:wilaya");
    if (w) wilayaId = Number(w);
  } catch {
    /* تجاهل */
  }
  const delivery = wilayaId ? getShippingFee(wilayaId, "home") : null;
  const total = subtotal + (delivery ?? 0);
  const blocked = evaluation.hasBlocking;

  return (
    <AppShell className="pb-44">
      <div className="space-y-4 pt-6">
        {/* رأس الصفحة: العنوان + إفراغ السلة */}
        <div className="flex items-center justify-between gap-2">
          <h1 className="text-h1 text-foreground">{t("bag_heading")}</h1>
          {bag.items.length > 0 && (
            <button
              onClick={() => setConfirmClear(true)}
              className="btn-danger-small flex items-center gap-1.5"
            >
              <Trash2 className="size-3.5" /> {t("bag_clear")}
            </button>
          )}
        </div>

        {bag.items.length === 0 && (
          <EmptyState
            Icon={ShoppingBag}
            title={t("bag_empty_title")}
            hint={t("bag_empty_hint")}
            action={
              <Link to="/explore" className="btn-primary">
                {t("bag_browse")}
              </Link>
            }
          />
        )}

        {/* تنبيه صريح: لماذا لا يمكن إتمام الطلب الآن */}
        {blocked && (
          <div
            role="alert"
            className="flex items-start gap-2.5 rounded-2xl border border-danger bg-danger-soft p-3.5"
          >
            <AlertTriangle className="mt-0.5 size-4 shrink-0 text-danger" />
            <div className="min-w-0 text-sm">
              <p className="font-bold text-danger">
                {t("bag_issues_title")}
              </p>
              <p className="mt-0.5 text-xs leading-relaxed text-danger/90">
                {evaluation.blockingCount === 1
                  ? t("bag_issue_one")
                  : t("bag_issue_many", { count: evaluation.blockingCount })}{" "}
                {t("bag_issue_hint")}
              </p>
            </div>
          </div>
        )}

        {/* المجموعات حسب المتجر */}
        {[...groups.entries()].map(([storeName, items]) => (
          <section key={storeName} className="space-y-2">
            <SectionHeader
              title={
                <span className="flex items-center gap-1.5">
                  <Store className="size-4 text-accent-ink" />
                  {storeName}
                </span>
              }
            />
            <div className="space-y-2">
              {items.map((r) => {
                const image = r.offer ? primaryImage(r.offer.images) : null;
                const name = r.offer?.product.name ?? r.item.name ?? t("bag_item_removed");
                const priceChanged = r.issues.find((i) => i.kind === "price_changed");
                return (
                  <div
                    key={r.item.offerId}
                    className={
                      "flex gap-3 rounded-2xl border bg-card p-3 " +
                      (r.issue ? "border-danger/50" : "border-border")
                    }
                  >
                    {r.offer ? (
                      <Link
                        to="/products/$productId"
                        params={{ productId: r.offer.product_id }}
                        className="size-20 shrink-0 overflow-hidden rounded-xl bg-neutral-100"
                      >
                        {image && (
                          <img
                            src={image}
                            alt=""
                            loading="lazy"
                            decoding="async"
                            className="size-full object-cover"
                          />
                        )}
                      </Link>
                    ) : (
                      <div className="size-20 shrink-0 animate-pulse rounded-xl bg-neutral-100" />
                    )}
                    <div className="min-w-0 flex-1 space-y-1">
                      <p className="line-clamp-1 text-sm font-semibold">{name}</p>
                      <p className="line-clamp-1 text-xs text-muted-foreground">
                        {r.offer?.store.name} {Object.values(r.item.options).join(" · ")}
                      </p>
                      <p key={r.item.quantity} className="animate-pop text-price text-accent-ink">
                        {formatDA((r.offer?.price ?? 0) * r.item.quantity)}
                      </p>
                      {priceChanged && (
                        <p className="text-[11px] font-medium text-warning">
                          {priceChanged.message}
                        </p>
                      )}
                      {r.issue && (
                        <p className="text-[11px] font-semibold text-danger">{r.issue.message}</p>
                      )}
                    </div>
                    <div className="flex flex-col items-end justify-between">
                      <button
                        aria-label={t("bag_remove_aria")}
                        onClick={() => bag.remove(r.item.offerId)}
                        className="flex size-9 items-center justify-center rounded-full transition hover:bg-danger-soft active:scale-95"
                      >
                        <Trash2 className="size-4 text-danger" />
                      </button>
                      <QtyStepper
                        value={r.item.quantity}
                        onChange={(v) => bag.setQty(r.item.offerId, v)}
                        max={r.offer?.stock_quantity ?? 10}
                        disabled={!!r.issue}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </section>
        ))}

        {bag.items.length > 0 && (
          <Link to="/explore" className="btn-ghost w-full py-1.5 text-sm">
            {t("bag_continue_shopping")}
          </Link>
        )}

        {/* ملخص الطلب */}
        {bag.items.length > 0 && (
          <div className="space-y-2 rounded-2xl border border-border bg-card p-4">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">{t("bag_subtotal")}</span>
              <b className="text-foreground">{formatDA(subtotal)}</b>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">{t("bag_shipping")}</span>
              {delivery != null ? (
                <b className="text-foreground">{formatDA(delivery)}</b>
              ) : (
                <span className="text-xs text-muted-foreground">{t("bag_shipping_pending")}</span>
              )}
            </div>
            <div className="flex justify-between border-t border-border pt-2">
              <span className="font-bold text-foreground">{t("bag_total")}</span>
              <b className="text-price text-accent-ink">{formatDA(total)}</b>
            </div>
          </div>
        )}
      </div>

      {/* شريط متابعة الطلب — ثابت أسفل الشاشة */}
      {bag.items.length > 0 && (
        <StickyActionBar>
          <div className="flex items-center justify-between px-1">
            <span className="text-sm font-semibold text-muted-foreground">
              {t("bag_cta_items", { count: bag.count })}
            </span>
            <b className="text-section text-accent-ink">{formatDA(total)}</b>
          </div>
          {blocked ? (
            <p className="mt-2 rounded-xl bg-danger-soft px-3 py-2 text-center text-xs font-bold text-danger">
              {t("bag_checkout_blocked")}
            </p>
          ) : (
            <Link to="/checkout" className="btn-primary mt-3 w-full">
              {t("bag_checkout_cta")} <ArrowLeft className="size-4" />
            </Link>
          )}
        </StickyActionBar>
      )}

      <ConfirmDialog
        open={confirmClear}
        title={t("bag_empty_confirm_title")}
        message={t("bag_empty_confirm_message")}
        confirmLabel={t("bag_empty_confirm_ok")}
        cancelLabel={t("bag_cancel")}
        onCancel={() => setConfirmClear(false)}
        onConfirm={() => {
          bag.clear();
          setConfirmClear(false);
        }}
      />
    </AppShell>
  );
}
